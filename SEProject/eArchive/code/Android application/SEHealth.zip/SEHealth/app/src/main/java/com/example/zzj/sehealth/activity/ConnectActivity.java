package com.example.zzj.sehealth.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.content.IntentCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.zzj.sehealth.R;
import com.example.zzj.sehealth.service.SocketService;

public class ConnectActivity extends Activity {

    private static final String TAG ="Connect";
    private Button toLoginBtn;
    private EditText ipaddress;
    private EditText portnum;
    private String preference = "PREFERENCES";
    private SharedPreferences sharedpreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connect);
        toLoginBtn = (Button)findViewById(R.id.tologinBtn);
        ipaddress = (EditText)findViewById(R.id.ipaddress);
        portnum = (EditText)findViewById(R.id.portnumber);
        sharedpreferences = getSharedPreferences(preference, Context.MODE_PRIVATE);

        if(sharedpreferences.contains("IPADDRESS"))
        {
            ipaddress.setText(sharedpreferences.getString("IPADDRESS", ""));
        }
        if(sharedpreferences.contains("PORTNUM"))
        {
            portnum.setText(sharedpreferences.getString("PORTNUM", ""));
        }
        toLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor=sharedpreferences.edit();
                editor.putString("IPADDRESS",ipaddress.getText().toString());
                editor.putString("PORTNUM", portnum.getText().toString());
                editor.commit();
                Intent Login = new Intent(getApplicationContext(), Login.class);
                startService(new Intent(getApplicationContext(),SocketService.class));
                Login.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | IntentCompat.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(Login);
            }
        });

    }




}
