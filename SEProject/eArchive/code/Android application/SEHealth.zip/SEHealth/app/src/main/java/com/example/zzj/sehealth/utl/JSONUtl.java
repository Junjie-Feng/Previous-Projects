package com.example.zzj.sehealth.utl;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by XiaowenJiang on 11/10/15.
 */
public class JSONUtl {
    //put user information in a jsonobject and convert to string
    public static String UserToJson(UserInform userInform)
    {
        JSONObject InformObject = new JSONObject();
        try {
            int command = 1;
            InformObject.put("Command",command);
            InformObject.put("Name",userInform.getName());
            InformObject.put("Password",userInform.getPassword());
            InformObject.put("Username",userInform.getUsername());
            InformObject.put("Email",userInform.getEmail());
            InformObject.put("Gender",userInform.getGender());

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return InformObject.toString();
    }

    public static UserInform JsonToUser(JSONObject object)
    {
        UserInform userInform = new UserInform();
        try {
            userInform.setUsername(object.getString("Username"));
            userInform.setName(object.getString("Name"));
            userInform.setEmail(object.getString("Email"));
            //userInform.setPassword(object.getString("Password"));
            userInform.setGender(object.getInt("Gender"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return userInform;
    }





}
