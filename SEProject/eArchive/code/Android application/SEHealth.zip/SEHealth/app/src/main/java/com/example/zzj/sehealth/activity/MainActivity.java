package com.example.zzj.sehealth.activity;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.TextView;

import com.example.zzj.sehealth.R;
import com.example.zzj.sehealth.service.SocketService;

/**
 * Created by XiaowenJiang on 11/27/15.
 */
public class MainActivity extends Activity {
    //added by jxw, TAG string
    private static final String TAG = "MainActivity";
    // added by jxw, username, service args
    private String username;
    SocketService mService;
    boolean mBound = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_main);
        Intent intent = getIntent();
        username = intent.getStringExtra(getString(R.string.username));
        //added by jxw, bind main activity to service
        Intent service = new Intent(getApplicationContext(), SocketService.class);
        bindService(service, mConnection, Context.BIND_AUTO_CREATE);
        TextView temp =(TextView)findViewById(R.id.display);
        temp.setText(username);
    }

    public String getUsername() {
        return username;
    }

    /** Defines callbacks for service binding, passed to bindService() */
    private ServiceConnection mConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName className,
                                       IBinder service) {
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            SocketService.LocalBinder binder = (SocketService.LocalBinder) service;
            mService = binder.getService();
            mBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            mBound = false;
        }
    };

    public SocketService getService() {
        return mService;
    }

    public boolean getmBound(){
        return mBound;
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop is called");
        // Unbind from the service
        if (mBound) {
            unbindService(mConnection);
            mBound = false;
        }
    }

}
