//Title: Final Project--Account Management System
//Course: 16:332:503 Programming Financial
//Name: Junjie Feng
//Date of Submission: 12/11/2013

#ifndef ACCOUNT_H
#define ACCOUNT_H
class Accout
{
public:

private:

};
#endif